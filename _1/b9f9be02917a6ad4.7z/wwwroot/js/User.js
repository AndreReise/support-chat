﻿"use strict";

class User {
    IsAuth = false;   
    Reasone = 2;
    constructor(reasone ) {
        this.Reasone = reasone;
    }
}